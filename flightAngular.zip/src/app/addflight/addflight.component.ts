import { Component, OnInit } from '@angular/core';
import { FlightService, Flight } from '../flight.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addflight',
  templateUrl: './addflight.component.html',
  styleUrls: ['./addflight.component.css']
})
export class AddflightComponent implements OnInit {

  flight : Flight=new Flight( 0,"","",0);

  constructor(private flightservice : FlightService, private router : Router) { }

  ngOnInit(): void {
  }
  addFlight()
  {
    console.log(this.flight);

    this.flightservice.addFlight(this.flight).subscribe(data=> {alert("Flight created successfully");});
    this.router.navigate(["showAll"])
  }

}
