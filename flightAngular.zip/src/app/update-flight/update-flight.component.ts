import { Component, OnInit } from '@angular/core';
import { Flight, FlightService } from '../flight.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-flight',
  templateUrl: './update-flight.component.html',
  styleUrls: ['./update-flight.component.css']
})
export class UpdateFlightComponent implements OnInit {

  flights : Flight=new Flight( 0,"","",0);
  submitted=false;
  temp: Flight;
  constructor(private flightservice : FlightService, private router : Router) { }

  ngOnInit(): void {
   }
//  update(temp)
//  {
// //    this.flightservice.modify(this.flights).subscribe(data=>{console.log(data);this.router.navigate(['/']);},
// //   error=>{console.log(error);})
//    this.flights=temp;
//    this.flag= true;
// }

// updateflightById()
//   {
//     console.log(this.flights);
//     this.flightservice.modify(this.flights).subscribe(data=>this.temp=data);
//     this.flag = false ;
//     this.flightservice.showAll();
//   }

view(){
  this.router.navigate(['showAll']);
  }

  updateflightById()
  {
    console.log(this.flights);
    this.flightservice.modify(this.flights).subscribe(data => console.log(data), error => console.log(error));
    this.flights = new Flight(0,"","",0);
    this.view();
  }
  onSubmit() {
    this.updateflightById();
    this.submitted = true;
  }

}
