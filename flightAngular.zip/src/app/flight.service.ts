import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
export class Flight{
  constructor(public flightNumber:number,public flightModel:String,	public carrierName:String,public seatCapacity:number)
    {}
  }
@Injectable({
  providedIn: 'root'
})
export class FlightService {
  
  set(flight: Flight) {
    throw new Error("Method not implemented.");
  }

  flights:Flight[];
  
  constructor(private httpservice:HttpClient) { }


  addFlight(flights) : Observable<Flight>
  {
    console.log(flights);
    return this.httpservice.post<Flight>("http://localhost:9085/flights/add",flights);
  }

 public  deleteFlightById(flights) 
{
 
  return this.httpservice.delete<Flight>("http://localhost:9085/flights/deleteById/"+flights.flightNumber);

}
showAll() 
{
  return this.httpservice.get<Flight[]>("http://localhost:9085/flights/all");
}
  
  modify(flights : Flight) : Observable<Flight>
{
  return this.httpservice.put<Flight>("http://localhost:9085/flights/modify",flights);
}
}
