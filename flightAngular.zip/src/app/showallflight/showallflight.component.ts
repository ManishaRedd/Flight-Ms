import { Component, OnInit } from '@angular/core';
import { Flight, FlightService } from '../flight.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-showallflight',
  templateUrl: './showallflight.component.html',
  styleUrls: ['./showallflight.component.css']
})
export class ShowallflightComponent implements OnInit {

  id:number;
  flights : Flight[];
  flag : boolean=false;
  constructor(private flightservice : FlightService, private router : Router) { }

  ngOnInit(): void {
    this.flightservice.showAll().subscribe(response =>this.handleSuccessfulResponse(response),);
  }
    handleSuccessfulResponse(response)
  {
      this.flights=response;
  }
  deleteFlightById(flight: Flight): void {
    this.flightservice.deleteFlightById(flight).subscribe( data => {
        this.flights = this.flights.filter(u => u !== flight);});
  }
  
   update(temp){
      this.flights = temp;
      temp = true;
    this.router.navigate(['/update']);

  }


}
