import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowallflightComponent } from './showallflight.component';

describe('ShowallflightComponent', () => {
  let component: ShowallflightComponent;
  let fixture: ComponentFixture<ShowallflightComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowallflightComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowallflightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
