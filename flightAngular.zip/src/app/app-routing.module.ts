import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddflightComponent } from './addflight/addflight.component';

import { ShowallflightComponent } from './showallflight/showallflight.component';
import { UpdateFlightComponent } from './update-flight/update-flight.component';


const routes: Routes = [
  {
    path:'add',
    component:AddflightComponent
  },
  
  {
    path : 'showAll',
    component : ShowallflightComponent
  },
  {
    path : 'update',
    component : UpdateFlightComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
