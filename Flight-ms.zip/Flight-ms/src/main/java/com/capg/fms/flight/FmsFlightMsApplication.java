package com.capg.fms.flight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FmsFlightMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FmsFlightMsApplication.class, args);
	}

}
