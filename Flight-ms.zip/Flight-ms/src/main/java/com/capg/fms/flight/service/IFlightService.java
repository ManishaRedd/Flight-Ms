package com.capg.fms.flight.service;

import java.util.List;

import com.capg.fms.flight.entity.Flight;
import com.capg.fms.flight.exception.FlightException;



public interface IFlightService {
	

	public Flight addFlight(Flight flight);
	
	public Flight modifyFlight(Flight flight)throws FlightException;
	
	public Flight findFlight(long flightNumber) throws FlightException;
	
	public Flight deleteFlight(long flightNumber) throws FlightException;
		
	public List<Flight> getAll();
}
