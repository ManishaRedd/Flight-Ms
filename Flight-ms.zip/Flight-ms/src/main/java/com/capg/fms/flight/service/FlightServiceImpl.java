package com.capg.fms.flight.service;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.fms.flight.entity.Flight;
import com.capg.fms.flight.exception.FlightException;
import com.capg.fms.flight.repo.IFlightRepo;



@Service
public class FlightServiceImpl implements IFlightService {


	@Autowired(required = true)
	IFlightRepo flightRepo;
	

	 @Override
	 @Transactional
	  public Flight addFlight (Flight flight) {
		  System.out.println(flight);
		  if(flightRepo.existsById(flight.getFlightNumber())) {
			 throw new RuntimeException("Flight Already Exits");
		  }
		 return flightRepo.saveAndFlush(flight);
	  }	
	  

	 @Override
		@Transactional
		public Flight deleteFlight(long flightNumber) throws FlightException{
		 Flight flight=null;
		 if(flightRepo.existsById(flightNumber))
		 {
		 flight=flightRepo.findById(flightNumber).get();
		 flightRepo.deleteById(flightNumber);
		 }
			return flight;
	 }
	 
	 @Override
	 @Transactional
		public Flight modifyFlight(Flight newFlightData) throws FlightException {
//		Flight flight=flightRepo.getOne(newFlightData.getFlightNumber());		
//		 flight.setFlightModel(newFlightData.getFlightModel());
//		 flight.setCarrierName(newFlightData.getCarrierName());
//		 flight.setSeatCapacity(newFlightData.getSeatCapacity());
		 Flight flight =null;
		 long fnum = newFlightData.getFlightNumber();
			if( flightRepo.existsById(fnum))
			{
				 flight = flightRepo.findById(fnum).get();
				 System.out.println(flight);
				// return flightRepo.saveAndFlush(newFlightData);
			}
			else
			{
				throw new FlightException("Id not found");
			}

			 return flightRepo.saveAndFlush(newFlightData);

	}

	 @Override
		public List<Flight> getAll(){	
			return flightRepo.findAll();
		}


	@Override
	public Flight findFlight(long flightNumber) throws FlightException {
    Flight flight=null;
    if(flightRepo.existsById(flightNumber))
    {
    	flight=flightRepo.findById(flightNumber).get();
    }
    else {
    	throw new FlightException(flightNumber+"NOT FOUND");
    }
    return flight;
	}
		

	
	
}
