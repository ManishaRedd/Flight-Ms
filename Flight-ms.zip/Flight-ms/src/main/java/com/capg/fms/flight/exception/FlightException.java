package com.capg.fms.flight.exception;

public class FlightException extends Exception {


	public FlightException(String message)
	{
		super(message);
	}
	public FlightException()
	{
		super();
	}
}
